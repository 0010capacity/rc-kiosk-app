# Gift Kiosk App 🎁

사용자가 A/B 품목 중 원하는 기념품 2개를 선택할 수 있는 키오스크 스타일 웹앱입니다.

## 📦 실행 방법

```bash
npm install
npm run dev
```

## 🚀 GitHub Pages 배포

```bash
npm run build
npm run deploy
```

> `vite.config.ts`의 base 경로는 저장소 이름에 따라 수정해야 합니다.